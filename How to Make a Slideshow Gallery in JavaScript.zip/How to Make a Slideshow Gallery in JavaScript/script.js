var image = new Array("images/img1.png", "images/img2.jpg", "images/img3.jpg", "images/img4.jpg");
var count = 0;
var length = image.length - 1;

function ChangeImage(num){
	
	count = count + num;

	if(count > length){
		count = 0;
	}
	
	if(count < 0){
		count = length;
	}
	
	document.slideshow.src = image[count];
	
	return false;
}

function SetAuto(){
	setInterval("ChangeImage(1)", 4000);
}
